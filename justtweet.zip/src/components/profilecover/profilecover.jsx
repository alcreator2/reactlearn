import '../../App.css';
import React, { Component } from 'react';

class ProfileCover extends Component{
    render()
    {
        return(
           <section className='profilecover'>
               <img src='pokhara.jpg'></img>
           </section>
        )
    }
}

export default ProfileCover;